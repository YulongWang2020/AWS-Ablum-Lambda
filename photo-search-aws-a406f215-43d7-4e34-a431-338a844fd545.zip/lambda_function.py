import json
import boto3
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import requests
def lambda_handler(event, context):
    print("data: ",event)
    query = event["queryStringParameters"]["q"]
    print(query)
    host = 'search-photosearch-6gskwrehc366vc2l2cfk3cjamm.us-east-1.es.amazonaws.com'
    
    region = 'us-east-1'

    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    es = Elasticsearch(
        hosts=[{'host': host, 'port': 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )
    
    lex = boto3.client('lex-runtime')
    
    response = lex.post_text(
        botName='photosearch',
        botAlias='photoablum',
        userId='asdasd',
        sessionAttributes={},
        inputText= query,
    )
    print(response)

    # result = es.search(
    #         index="photos",
    #         body={
    #             "query": {
    #                 "match_all":{}
    #                 }
    #             }
    #         )
    
    # print(result)
    
    if "slots" in response.keys():
        url = []
        if response["slots"]["queryone"]:
            result = es.search(
                index="photos",
                body={
                    "query": {
                        "match":{
                            "labels": response["slots"]["queryone"]
                            }
                        }
                    }
                )
            print(result)
            for each in result["hits"]["hits"]:
                key = each["_source"]["objectKey"]
                tempurl = "https://photo-album-aws.s3.amazonaws.com/" + key
                url.append(tempurl)
            
            
        if response["slots"]["querytwo"]:
            result = es.search(
                index="photos",
                body={
                    "query": {
                        "match":{
                            "labels": response["slots"]["querytwo"]
                            }
                        }
                    }
                )
            print(result)
            for each in result["hits"]["hits"]:
                key = each["_source"]["objectKey"]
                tempurl = "https://photo-album-aws.s3.amazonaws.com/" + key
                url.append(tempurl)
        url = list(set(url))
        url_str = ""
        for each in url:
            url_str += each+","
            
        print(url_str)
    
    return {
        "isBase64Encoded": False,
        "statusCode": 200,
        "headers": { "Access-Control-Allow-Origin": "*"},
        "multiValueHeaders": {},
        # "body": "url"
        "body": url_str
    }
